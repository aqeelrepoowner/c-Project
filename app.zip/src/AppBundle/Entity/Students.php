<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="students")
 *
 * Defines the properties of the Post entity to represent the blog posts.
 *
 * See http://symfony.com/doc/current/book/doctrine.html#creating-an-entity-class
 *
 * Tip: if you have an existing database, you can generate these entity class automatically.
 * See http://symfony.com/doc/current/cookbook/doctrine/reverse_engineering.html
 *
 * @author Ryan Weaver <weaverryan@gmail.com>
 * @author Javier Eguiluz <javier.eguiluz@gmail.com>
 */
class Students
{
    /**
     * Use constants to define configuration options that rarely change instead
     * of specifying them in app/config/config.yml.
     *
     * See http://symfony.com/doc/current/best_practices/configuration.html#constants-vs-configuration-options
     */
    const NUM_ITEMS = 10;

    /**
     * @var int
     *
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(type="string")
     *  @Assert\NotBlank(message="First Name should not be blank")
     *  @Assert\Length(max=50, maxMessage="First Name field exceeded number of characters")
     */
    private $first_name;

    /**
     * @var string
     *
     * @ORM\Column(type="string")
     *  @Assert\NotBlank(message="Last Name should not be blank")
     *  @Assert\Length(max=50, maxMessage="Last Name field exceeded number of characters")
     */
    private $last_name;

    /**
     * @var string
     *
     * @ORM\Column(type="string")
     *  @Assert\NotBlank(message="Email should not be blank")
     *  @Assert\Length(max=50, maxMessage="Email field exceeded number of characters")
     *  @Assert\Email(
     *     message = "The email '{{ value }}' is not a valid email.",
     *     checkMX = true
     *  )
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(type="string")
     *  @Assert\NotBlank(message="Father Name should not be empty")
     *  @Assert\Length(max=50, maxMessage="Father Name field exceeded number of characters")
     */
    private $fatherName;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime")
     *  @Assert\DateTime
     */
    private $registered_date;

     /**
     * @var string
     *
     * @ORM\Column(type="string")
     */
    private $gender;

    /**
     * @var date
     *
     * @ORM\Column(type="date")
     */
    private $dob;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=12)
     */
    private $contact_no;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean")
     */
    private $bus_facility;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=10)
     */
    private $status;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50)
     */
    private $school_name;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50)
     */
    private $school_medium;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=500)
     */
    private $address;

    /**
     * @var Course
     *
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\Course")
     * @ORM\JoinColumn(nullable=false)
     */
    private $course;

    /**
     * @var Teachers
     *
     * @ORM\ManyToOne(
     *      targetEntity="AppBundle\Entity\Teachers"
     * )
     * @ORM\JoinColumn(nullable=false)
     */
    private $teacher;

    /**
     * @var Maktab
     *
     * @ORM\ManyToOne(
     *      targetEntity="AppBundle\Entity\Maktab"
     * )
     * @ORM\JoinColumn(nullable=false)
     */
    private $maktab;

    public function __construct()
    {
        $this->registered_date = new \DateTime();
    }

    public function getId()
    {
        return $this->id;
    }

    /**
     * Set firstName
     *
     * @param string $firstName
     *
     * @return Students
     */
    public function setFirstName($firstName)
    {
        $this->first_name = $firstName;

        return $this;
    }

    /**
     * Get firstName
     *
     * @return string
     */
    public function getFirstName()
    {
        return $this->first_name;
    }

    /**
     * Set lastName
     *
     * @param string $lastName
     *
     * @return Students
     */
    public function setLastName($lastName)
    {
        $this->last_name = $lastName;

        return $this;
    }

    /**
     * Get lastName
     *
     * @return string
     */
    public function getLastName()
    {
        return $this->last_name;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return Students
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set fatherName
     *
     * @param string $fatherName
     *
     * @return Students
     */
    public function setFatherName($fatherName)
    {
        $this->fatherName = $fatherName;

        return $this;
    }

    /**
     * Get fatherName
     *
     * @return string
     */
    public function getFatherName()
    {
        return $this->fatherName;
    }

    /**
     * Set registeredDate
     *
     * @param \DateTime $registeredDate
     *
     * @return Students
     */
    public function setRegisteredDate($registeredDate)
    {
        $this->registered_date = $registeredDate;

        return $this;
    }

    /**
     * Get registeredDate
     *
     * @return \DateTime
     */
    public function getRegisteredDate()
    {
        return $this->registered_date;
    }

    /**
     * Set gender
     *
     * @param string $gender
     *
     * @return Students
     */
    public function setGender($gender)
    {
        $this->gender = $gender;

        return $this;
    }

    /**
     * Get gender
     *
     * @return string
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     * Set courseId
     *
     * @param \AppBundle\Entity\Course $courseId
     *
     * @return Students
     */
    public function setCourseId(\AppBundle\Entity\Course $courseId)
    {
        $this->courseId = $courseId;

        return $this;
    }

    /**
     * Set contactNo
     *
     * @param string $contactNo
     *
     * @return Students
     */
    public function setContactNo($contactNo)
    {
        $this->contact_no = $contactNo;

        return $this;
    }

    /**
     * Get contactNo
     *
     * @return string
     */
    public function getContactNo()
    {
        return $this->contact_no;
    }

    /**
     * Set dob
     *
     * @param \DateTime $dob
     *
     * @return Students
     */
    public function setDob($dob)
    {
        $this->dob = $dob;

        return $this;
    }

    /**
     * Get dob
     *
     * @return \DateTime
     */
    public function getDob()
    {
        return $this->dob;
    }

    /**
     * Set course
     *
     * @param \AppBundle\Entity\Course $course
     *
     * @return Students
     */
    public function setCourse(\AppBundle\Entity\Course $course)
    {
        $this->course = $course;

        return $this;
    }

    /**
     * Get course
     *
     * @return \AppBundle\Entity\Course
     */
    public function getCourse()
    {
        return $this->course;
    }

    /**
     * Set teacher
     *
     * @param \AppBundle\Entity\Teachers $teacher
     *
     * @return Students
     */
    public function setTeacher(\AppBundle\Entity\Teachers $teacher)
    {
        $this->teacher = $teacher;

        return $this;
    }

    /**
     * Get teacher
     *
     * @return \AppBundle\Entity\Teachers
     */
    public function getTeacher()
    {
        return $this->teacher;
    }

    /**
     * Set maktab
     *
     * @param \AppBundle\Entity\Maktab $maktab
     *
     * @return Students
     */
    public function setMaktab(\AppBundle\Entity\Maktab $maktab)
    {
        $this->maktab = $maktab;

        return $this;
    }

    /**
     * Get maktab
     *
     * @return \AppBundle\Entity\Maktab
     */
    public function getMaktab()
    {
        return $this->maktab;
    }

    /**
     * Set busFacility
     *
     * @param boolean $busFacility
     *
     * @return Students
     */
    public function setBusFacility($busFacility)
    {
        $this->bus_facility = $busFacility;

        return $this;
    }

    /**
     * Get busFacility
     *
     * @return boolean
     */
    public function getBusFacility()
    {
        return $this->bus_facility;
    }

    /**
     * Set status
     *
     * @param string $status
     *
     * @return Students
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set schoolName
     *
     * @param string $schoolName
     *
     * @return Students
     */
    public function setSchoolName($schoolName)
    {
        $this->school_name = $schoolName;

        return $this;
    }

    /**
     * Get schoolName
     *
     * @return string
     */
    public function getSchoolName()
    {
        return $this->school_name;
    }

    /**
     * Set schoolMedium
     *
     * @param string $schoolMedium
     *
     * @return Students
     */
    public function setSchoolMedium($schoolMedium)
    {
        $this->school_medium = $schoolMedium;

        return $this;
    }

    /**
     * Get schoolMedium
     *
     * @return string
     */
    public function getSchoolMedium()
    {
        return $this->school_medium;
    }

    /**
     * Set address
     *
     * @param string $address
     *
     * @return Students
     */
    public function setAddress($address)
    {
        $this->address = $address;

        return $this;
    }

    /**
     * Get address
     *
     * @return string
     */
    public function getAddress()
    {
        return $this->address;
    }
}
