<?php
namespace Acm\ApiBundle\Controller;
use Acm\ApiBundle\Entity\User;
use Acm\ApiBundle\Form\userType;
use FOS\RestBundle\Controller\Annotations as FOSRestBundleAnnotations;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Routing\ClassResourceInterface;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;  

/**
 * @FOSRestBundleAnnotations\View()
 */
class UsersController extends FOSRestController implements ClassResourceInterface
{
    /**       
    * @return array       
    * @Rest\Get("/users")       
    * @Rest\View       
    */    
    public function cgetAction()
    {
        $em = $this->getDoctrine()->getEntityManager();
        $repository = $em->getRepository("ApiBundle:User");
        $users = $repository->findAll();
        return $users;
    }

    /**
    * POST Route annotation.
    * @Rest\Post("/users/new")
    * @Rest\View
    * @return array
    */
    public function newUserAction(Request $request)
    {
        $userManager = $this->get('fos_user.user_manager');

        $email = $request->request->get('email');
        $username = $request->request->get('username');
        $password = $request->request->get('password');

        $email_exist = $userManager->findUserByEmail($email);
        $username_exist = $userManager->findUserByUsername($username);

        if($email_exist || $username_exist){
            $response = new JsonResponse();
            $response->setData("Username/Email ".$username."/".$email." already exists!");
            return $response;
        }

        $user = $userManager->createUser();
        $user->setUsername($username);
        $user->setEmail($email);
        $user->setEmailCanonical($email);
        $user->setLocked(false); 
        $user->setEnabled(true); 
        $user->setPlainPassword($password);
        $userManager->updateUser($user, true);

        $response = new JsonResponse();
        $response->setData("User: ".$user->getUsername()." created successfully");
        return $response;
    }
}
