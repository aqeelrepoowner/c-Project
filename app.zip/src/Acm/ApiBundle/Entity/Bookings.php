<?php
// src/Acme/ApiBundle/Entity/Client.php

namespace Acm\ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 */
class Bookings
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

   /**
    * @ORM\Column(type="string")
    */
    protected $title;

   /**
    * @ORM\Column(type="string")
    */
    protected $fromPlaceCoordinates;

   /**
    * @ORM\Column(type="string")
    */
    protected $toPlaceCoordinates;

   /**
    * @ORM\Column(type="datetime")
    */
    protected $departDate;
    
   /**
    * @ORM\Column(type="float")
    */
    protected $kmsToTravel;

    /**
     * @var User
     *
     * @ORM\ManyToOne(targetEntity="Acm\ApiBundle\Entity\User")
     * @ORM\JoinColumn(nullable=false)
     */
    protected $user;

    

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Bookings
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set fromPlaceCoordinates
     *
     * @param string $fromPlaceCoordinates
     *
     * @return Bookings
     */
    public function setFromPlaceCoordinates($fromPlaceCoordinates)
    {
        $this->fromPlaceCoordinates = $fromPlaceCoordinates;

        return $this;
    }

    /**
     * Get fromPlaceCoordinates
     *
     * @return string
     */
    public function getFromPlaceCoordinates()
    {
        return $this->fromPlaceCoordinates;
    }

    /**
     * Set toPlaceCoordinates
     *
     * @param string $toPlaceCoordinates
     *
     * @return Bookings
     */
    public function setToPlaceCoordinates($toPlaceCoordinates)
    {
        $this->toPlaceCoordinates = $toPlaceCoordinates;

        return $this;
    }

    /**
     * Get toPlaceCoordinates
     *
     * @return string
     */
    public function getToPlaceCoordinates()
    {
        return $this->toPlaceCoordinates;
    }

    /**
     * Set departDate
     *
     * @param \DateTime $departDate
     *
     * @return Bookings
     */
    public function setDepartDate($departDate)
    {
        $this->departDate = $departDate;

        return $this;
    }

    /**
     * Get departDate
     *
     * @return \DateTime
     */
    public function getDepartDate()
    {
        return $this->departDate;
    }

    /**
     * Set kmsToTravel
     *
     * @param float $kmsToTravel
     *
     * @return Bookings
     */
    public function setKmsToTravel($kmsToTravel)
    {
        $this->kmsToTravel = $kmsToTravel;

        return $this;
    }

    /**
     * Get kmsToTravel
     *
     * @return float
     */
    public function getKmsToTravel()
    {
        return $this->kmsToTravel;
    }
}
