<?php
namespace Acm\ApiBundle\Controller;
use Acm\ApiBundle\Entity\Bookings;
use Acm\ApiBundle\Form\BookingsType;
use FOS\RestBundle\Controller\Annotations as FOSRestBundleAnnotations;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Routing\ClassResourceInterface;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;  

/**
 * @FOSRestBundleAnnotations\View()
 */
class BookingsController extends FOSRestController implements ClassResourceInterface
{
    /**       
    * @return array       
    * @Rest\Get("/bookings")       
    * @Rest\View       
    */    
    public function bookingsAction()
    {
        $em = $this->getDoctrine()->getEntityManager();
        $repository = $em->getRepository("ApiBundle:User");
        $users = $repository->findAll();
        return $users;
    }

    /**
    * POST Route annotation.
    * @Rest\Post("/bookings/new")
    * @Rest\View
    * @return array
    */
    public function postAction(Request $request)
    {
        $user = new User();
        $userForm = $this->createForm(new UserType(), $user);
        $userForm->handleRequest($request);
        if ($userForm->isValid()) {
            $em = $this->getDoctrine()->getEntityManager();
            $em->persist($user);
            $em->flush();
            return $user;
        }
        return $userForm->getErrors();
    }
}
